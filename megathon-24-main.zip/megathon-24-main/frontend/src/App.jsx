import Chatbot from "./components/Chatbot"

export default function App() {
  return (
      <Chatbot />
  )
}