# wsgi.py

from chatbot import app  # Import your Flask app from the module where it is defined

if __name__ == "__main__":
    app.run()
